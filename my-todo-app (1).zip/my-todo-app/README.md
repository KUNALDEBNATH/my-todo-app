# ✌️ Just Do It — Todo App

## How to Run

1. Extract this ZIP anywhere on your PC
2. Open the folder `my-todo-app` in Command Prompt or PowerShell
3. Run these commands one by one:

```
npm install
npm run dev
```

4. Open your browser at: http://localhost:5173

That's it! 🎉
